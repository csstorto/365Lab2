# 365-lab-2

## Run program

- `git clone https://github.com/ZRich97/365-lab-1.git`

- `cd 365-lab-1`

- `python3 schoolsearch.py`

## Commit new code

- Make desired changes

- `git add -A`

- `git commit -m "YOUR MESSAGE"`

- `git push`
